using UnityEngine;

public class PokeballThrow : MonoBehaviour
{
    public Transform targetPokemon;       // 拖入場景中的寶可夢
    public ParticleSystem captureEffect;  // 拖入場景中的收服特效
    public float throwDuration = 1.2f;    // 飛行時間（秒）
    public float arcHeight = 2.5f;        // 拋物線弧度高度

    private Vector3 startPos;
    private float timer = 0f;
    private bool isThrown = false;

    void Start()
    {
        startPos = transform.position;
    }

    void Update()
    {
        // 按下空白鍵，精靈球由左至右拋向寶可夢
        if (Input.GetKeyDown(KeyCode.Space) && !isThrown && targetPokemon != null)
        {
            isThrown = true;
        }

        if (isThrown)
        {
            timer += Time.deltaTime;
            float progress = Mathf.Clamp01(timer / throwDuration);

            // 計算由左至右的水平插值 + 拋物線高度
            Vector3 currentPos = Vector3.Lerp(startPos, targetPokemon.position, progress);
            currentPos.y += Mathf.Sin(progress * Mathf.PI) * arcHeight;
            transform.position = currentPos;

            // 飛行時順時針旋轉
            transform.Rotate(Vector3.forward * -360f * Time.deltaTime);
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        // 碰到寶可夢時觸發收服與特效
        if (other.CompareTag("Pokemon"))
        {
            isThrown = false;

            if (captureEffect != null)
            {
                captureEffect.transform.position = other.transform.position;
                captureEffect.Play();
            }

            // 隱藏寶可夢代表已收服
            other.gameObject.SetActive(false);
        }
    }
}
